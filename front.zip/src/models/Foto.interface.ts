export interface Foto {
    idFoto: number;
    link:   string;
}
